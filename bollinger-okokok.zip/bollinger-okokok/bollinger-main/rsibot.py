import os
import time
import pandas as pd
from binance.client import Client
client = Client()
from ta.momentum import RSIIndicator
from win10toast import ToastNotifier
import telegram

# Credenciales de Binance
api_key = 'TU_API_KEY'
api_secret = 'TU_API_SECRET'
client = Client(api_key, api_secret)

INTERVAL = Client.KLINE_INTERVAL_5MINUTE

toaster = ToastNotifier()

# Credenciales del bot de Telegram
bot_token = '5439702151:AAHnPjMVB0bNyzDGjebSHuuROpX2OQ_flSg'
chat_id = '803228423'  # ID del chat donde se recibirán las alertas

# Crear objeto del bot
bot = telegram.Bot(token=bot_token)

def run_scanner():
    print(f'Analizando monedas en {pd.Timestamp.now()}')
    prices = client.futures_ticker()
    for coin in prices:
        symbol = coin['symbol']
        if symbol == 'HNTUSDT':
            continue
        if 'USDT' in symbol and symbol.endswith('USDT'):
            ticker = client.futures_ticker(symbol=symbol)
            price = float(ticker['lastPrice'])
            rsi = get_rsi(symbol)
            if rsi > 80:
                message = f"{symbol} ha superado el RSI 80 (PATRON PODEROSO) 🔴 SHORT ({rsi:.2f}). Precio actual:     {price:.2f}"
                print(message)
                toaster.show_toast("Alerta RSI", message, duration=2)
                bot.send_message(chat_id=chat_id, text=message)     
            elif rsi < 20:
                message = f"{symbol} ha caído por debajo del RSI 20  🟢 LONG ({rsi:.2f}). Precio actual:      {price:.2f}"
                print(message)
                toaster.show_toast("Alerta RSI", message, duration=2)
                bot.send_message(chat_id=chat_id, text=message)
            else:
                print(f"{symbol} RSI: {rsi:.2f}. Precio actual: {price:.2f}")


def get_rsi(symbol):
    klines = client.futures_historical_klines(symbol=symbol, interval=INTERVAL, limit=1000, start_str='2 days ago UTC')
    df = pd.DataFrame(klines, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_asset_volume', 'num_trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
    close = df['close'].astype(float)
    rsi_indicator = RSIIndicator(close=close, window=14)
    rsi = rsi_indicator.rsi()
    return rsi.iloc[-1]

if __name__ == '__main__':
    while True:
        run_scanner()
        time.sleep(5) # scanner cada 5 seg
